# Integración del módulo Proveedores y Compras

Copie cada carpeta dentro de `src/` del proyecto, respetando las rutas (no sobrescribe nada existente).

| Archivo nuevo | Destino |
|---|---|
| `PuntoVenta.Shared/Dtos/Proveedores/ProveedorDtos.cs` | `src/PuntoVenta.Shared/Dtos/Proveedores/` |
| `PuntoVenta.Shared/Dtos/Compras/CompraDtos.cs` | `src/PuntoVenta.Shared/Dtos/Compras/` |
| `PuntoVenta.API/Controllers/ProveedoresController.cs` | `src/PuntoVenta.API/Controllers/` |
| `PuntoVenta.API/Controllers/ComprasController.cs` | `src/PuntoVenta.API/Controllers/` |
| `PuntoVenta.Web/Services/ApiClienteEscrituraBase.cs`, `ProveedorService.cs`, `CompraService.cs` | `src/PuntoVenta.Web/Services/` |
| `PuntoVenta.Web/Components/Pages/Proveedores/Proveedores.razor` | `src/PuntoVenta.Web/Components/Pages/Proveedores/` |
| `PuntoVenta.Web/Components/Pages/Compras/Compras.razor`, `CompraNueva.razor` | `src/PuntoVenta.Web/Components/Pages/Compras/` |
| `BaseDeDatos/04_Menu_Compras_Proveedores.sql` | ejecutar en MySQL |

## Cambios en archivos existentes (3 líneas)

**`PuntoVenta.Web/Program.cs`** — junto a los `AddScoped` de servicios:

```csharp
builder.Services.AddScoped<ProveedorService>();
builder.Services.AddScoped<CompraService>();
```

**`PuntoVenta.Web/Components/_Imports.razor`** — al final:

```razor
@using PuntoVenta.Shared.Dtos.Proveedores
@using PuntoVenta.Shared.Dtos.Compras
```

La API (`Program.cs`) no necesita cambios: los controladores se registran solos con `MapControllers()`.
No se crean tablas: `proveedores`, `compras` y `compras_detalle` ya existen en `PuntoVentaDB.sql`.
