-- Opciones de menú para Proveedores y Compras.
-- Ajuste "orden", "icono" y "id_menu_padre" para que sean iguales a las filas de
-- 01_Menu_Opciones.sql (por ejemplo, si el menú tiene un grupo padre "Operaciones").
USE puntoventadb;

INSERT INTO menu (nombre, ruta, icono, id_menu_padre, orden, estado)
SELECT "Proveedores", "/proveedores", "bi-truck", NULL, 50, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM menu WHERE ruta = "/proveedores");

INSERT INTO menu (nombre, ruta, icono, id_menu_padre, orden, estado)
SELECT "Compras", "/compras", "bi-bag-plus", NULL, 60, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM menu WHERE ruta = "/compras");
